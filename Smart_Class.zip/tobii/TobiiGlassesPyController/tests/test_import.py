import pytest

def test_import():
  import tobiiglassesctrl
